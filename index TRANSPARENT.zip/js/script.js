document.addEventListener('DOMContentLoaded', () => {

    /**
     * Stable Script - Post Smooth Scroll Removal
     * This version reverts to the state before smooth scrolling was implemented
     * to ensure stability, but includes the enhanced diamond.
     */

    // --- 1. Loading Bar Simulation ---
    // --- 1. Loading Bar Simulation ---
    const loadingBar = document.querySelector('.loading-bar');
    if (loadingBar) {
        // slight delay to ensure the transition is visible
        setTimeout(() => {
            loadingBar.style.transform = 'scaleX(1)';
        }, 100);

        loadingBar.addEventListener('transitionend', () => {
            // fading out
            loadingBar.style.opacity = '0';
            setTimeout(() => {
                loadingBar.style.display = 'none';
            }, 500);
        });
    }

    // --- 2. 3D Hero Scene ---
    class DiamondHero {
        constructor() {
            this.canvas = document.querySelector('canvas.webgl');
            if (!this.canvas) return;
            this.init();
        }

        setupScrollEvent() {
            this.scrollY = 0;
            window.addEventListener('scroll', () => {
                this.scrollY = window.scrollY;
            });
        }

        init() {
            this.setupScene();
            this.setupLights();
            this.createCrystalShell(); // Enhanced diamond
            this.setupParticles();
            this.setupMouseEvent();
            this.setupScrollEvent(); // Add scroll tracking

            this.clock = new THREE.Clock();
            this.render(); // This class manages its own render loop

            window.addEventListener('resize', this.resize.bind(this));
        }

        setupScene() {
            this.scene = new THREE.Scene();
            this.sizes = { width: window.innerWidth, height: window.innerHeight };
            this.camera = new THREE.PerspectiveCamera(35, this.sizes.width / this.sizes.height, 0.1, 100);
            this.camera.position.z = 6;
            this.scene.add(this.camera);

            this.renderer = new THREE.WebGLRenderer({
                canvas: this.canvas,
                alpha: true,
                antialias: true
            });
            this.renderer.setSize(this.sizes.width, this.sizes.height);
            this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        }

        setupLights() {
            this.scene.add(new THREE.AmbientLight(0xffffff, 0.7));
            const pointLight = new THREE.PointLight(0xadd8e6, 0.8); // Light blue light
            pointLight.position.set(-5, -5, -5);
            this.scene.add(pointLight);
            const pointLight2 = new THREE.PointLight(0xffffff, 0.5);
            pointLight2.position.set(5, 5, 5);
            this.scene.add(pointLight2);
        }

        createCrystalShell() {
            this.diamondGroup = new THREE.Group();

            // Diamond Profile Points (approximating an Ideal Brilliant Cut)
            // Normalized Radius = 1.5 (matches previous scale)
            const r = 1.5;
            const points = [];
            points.push(new THREE.Vector2(0, -1.1 * r));    // Culet (Tip)
            points.push(new THREE.Vector2(1 * r, 0));       // Girdle (Widest point)
            points.push(new THREE.Vector2(0.6 * r, 0.35 * r));  // Table Edge
            points.push(new THREE.Vector2(0.0, 0.35 * r));  // Table Center

            // Create Geometry (16 segments for a faceted look)
            const diamondGeometry = new THREE.LatheGeometry(points, 16);
            diamondGeometry.computeVertexNormals();

            // Center the geometry
            diamondGeometry.center();

            // 1. Crystal Material (Outer Shell)
            const outerMaterial = new THREE.MeshPhysicalMaterial({
                metalness: 0,
                roughness: 0,
                transmission: 0.97,
                ior: 2.418,
                thickness: 0.8,
                color: 0xffffff,
                envMapIntensity: 1,
                flatShading: true // Faceted look
            });
            const outerShell = new THREE.Mesh(diamondGeometry, outerMaterial);

            // 2. Inner Core (Glow) - Use same geometry but scaled down
            const innerGeometry = diamondGeometry.clone();
            innerGeometry.scale(0.5, 0.5, 0.5); // Smaller core

            const innerMaterial = new THREE.MeshBasicMaterial({
                color: 0x535DA8, // Royal violet from theme
                blending: THREE.AdditiveBlending,
                depthWrite: false,
                side: THREE.BackSide,
                wireframe: true, // Wireframe for tech look
                transparent: true,
                opacity: 0.3
            });
            const innerCore = new THREE.Mesh(innerGeometry, innerMaterial);

            this.diamondGroup.add(outerShell, innerCore);
            this.scene.add(this.diamondGroup);
        }

        setupParticles() {
            const particlesCount = 5000;
            const positions = new Float32Array(particlesCount * 3);
            for (let i = 0; i < particlesCount * 3; i++) positions[i] = (Math.random() - 0.5) * 15;
            const particlesGeometry = new THREE.BufferGeometry();
            particlesGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
            const particlesMaterial = new THREE.PointsMaterial({ color: 0xffffff, size: 0.02, sizeAttenuation: true });
            this.particles = new THREE.Points(particlesGeometry, particlesMaterial);
            this.scene.add(this.particles);
        }

        setupMouseEvent() {
            this.cursor = { x: 0, y: 0 };
            window.addEventListener('mousemove', (e) => {
                this.cursor.x = e.clientX / this.sizes.width - 0.5;
                this.cursor.y = e.clientY / this.sizes.height - 0.5;
            });
        }

        // This is the main render loop for the 3D scene
        render() {
            const elapsedTime = this.clock.getElapsedTime();
            const deltaTime = this.clock.getDelta(); // Get delta time for smooth motion

            // Animate the entire group
            if (this.diamondGroup) {
                // Continuous slow rotation + Scroll-driven "Orbit" rotation
                // The scrollY factor makes it feel like we are spiraling around the diamond
                this.diamondGroup.rotation.y = (elapsedTime * 0.1) + (this.scrollY * 0.0015);
                this.diamondGroup.rotation.x = Math.sin(elapsedTime * 0.2) * 0.1; // Gentle bobbing

                // Animate the inner core independently for a shimmer effect
                if (this.diamondGroup.children[1]) {
                    this.diamondGroup.children[1].rotation.y = elapsedTime * 0.2;
                    this.diamondGroup.children[1].rotation.x = elapsedTime * 0.1;
                }
            }

            // Parallax mouse effect
            const parallaxX = this.cursor.x * 0.5;
            const parallaxY = -this.cursor.y * 0.5;
            this.camera.position.x += (parallaxX - this.camera.position.x) * 3 * deltaTime;
            this.camera.position.y += (parallaxY - this.camera.position.y) * 3 * deltaTime;

            // Animate particles
            if (this.particles) {
                this.particles.rotation.y = -elapsedTime * 0.05;
                this.particles.position.y = -this.scrollY * 0.0005; // Particles drift up as we scroll down
            }

            this.renderer.render(this.scene, this.camera);
            window.requestAnimationFrame(this.render.bind(this));
        }

        resize() {
            this.sizes.width = window.innerWidth;
            this.sizes.height = window.innerHeight;
            this.camera.aspect = this.sizes.width / this.sizes.height;
            this.camera.updateProjectionMatrix();
            this.renderer.setSize(this.sizes.width, this.sizes.height);
            this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        }
    }

    // --- Other UX Modules ---

    // Adds a mouse-tracking glow effect to all glass cards.
    function setupCardHoverEffect() {
        const cards = document.querySelectorAll('.glass-card');
        cards.forEach(card => {
            card.addEventListener('mousemove', (e) => {
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                card.style.setProperty('--mouse-x', `${x}px`);
                card.style.setProperty('--mouse-y', `${y}px`);
            });
        });
    }

    // Handles the parallax and fade effects for content layers on scroll.
    function setupLayerParallax() {
        const hero = document.querySelector('.hero-section');
        const contentSections = document.querySelectorAll('main section'); // This now only targets 'main section'

        window.addEventListener('scroll', () => {
            const scrollY = window.scrollY;
            const viewportHeight = window.innerHeight;

            // Fade out hero text
            const heroOpacity = 1 - Math.min(1, scrollY / (viewportHeight * 0.8));
            if (hero) hero.style.opacity = heroOpacity;

            // Parallax on sections disabled to prevent conflict with entrance animations
            // If parallax is desired, apply it to children elements or use a library that handles both

        });
    }

    // Entrance Animations on Scroll using IntersectionObserver
    function setupEntranceAnimations() {
        const sectionsToReveal = document.querySelectorAll('.story-chapter, .product-section, .trust-signals');
        const observerOptions = { root: null, rootMargin: '0px', threshold: 0.2 };
        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);
        sectionsToReveal.forEach(section => observer.observe(section));
    }

    // --- Initialize all modules ---
    new DiamondHero();
    setupCardHoverEffect();
    setupLayerParallax();
    setupEntranceAnimations();
});